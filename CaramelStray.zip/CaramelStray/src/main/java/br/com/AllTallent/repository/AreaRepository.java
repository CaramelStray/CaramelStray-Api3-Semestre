package br.com.AllTallent.repository;

import br.com.AllTallent.model.Area;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AreaRepository extends JpaRepository<Area, Integer> {
    // A interface deve ficar vazia aqui dentro.
}