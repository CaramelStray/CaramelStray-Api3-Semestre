package br.com.AllTallent.caramelstray;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaramelStrayApplicationTests {

    @Test
    void contextLoads() {
    }

}
